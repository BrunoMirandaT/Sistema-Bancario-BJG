package aplicacao;

import java.util.Scanner;
import entidades.Btg;
import java.time.ZonedDateTime;

public class Main {

	public static void main(String[] args){
		
		int opcao, repeat = 0;
		
		Scanner sc = new Scanner(System.in);
	
		Btg user = new Btg();
		
		System.out.println("Digite seu nome:");
		user.nome = sc.nextLine();
		
		System.out.println("Digite seu endereco:");
		user.endereco = sc.nextLine();
		
		System.out.println("Digite seu CPF:");
		user.CPF = sc.nextLine();
		
		System.out.println("Qual � a sua profissao:");
		user.profissao = sc.nextLine();
		
		System.out.println("Digite sua renda mensal:");
		user.renda = sc.nextDouble();
		
		System.out.println("Informe o numero do seu cartao:");
		user.numero = sc.nextLong();
					
		System.out.println("Informe sua agencia:");
		user.agencia = sc.next();
		
		do {
		System.out.println(ZonedDateTime.now());
		System.out.println("\nBom dia "+user.nome);
		
		System.out.println("Saldo: R$"+user.saldo);
		
		switch(user.notifEMP) {
		case 1:System.out.println("Voce tem um emprestimo a pagar no valor de R$"+user.quantiaTotal+ " em "+user.tempo+ " meses");
		break;
		}
		
		System.out.println("\n1 - Depositar\n2 - Transferir\n3 - Investir\n4 - Emprestimo\n5 - Minhas informacoes\n6 - Sair");
		System.out.println("Escolha uma opcao:");
		opcao = sc.nextInt();
		
		switch(opcao) {
		case 1:
			System.out.println("Informe a quantia a ser depositada:");
			user.quantia = sc.nextDouble();
			
			user.saldo = user.depositar();
			System.out.println("Seu novo saldo e: R$"+user.saldo);
			break;
		
		case 2:
			System.out.println("Digite o nome da pessoa que recebera a tranferencia:");
			user.nomeTrans = sc.next();
			
			System.out.println("Digite o CPF da pessoa que recebera a transferencia:");
			user.cpfTrans = sc.next();
			
			System.out.println("Informe a agencia da pessoa que recebera a transferencia:");
			user.agenciaTrans = sc.next();
			
			System.out.println("Digite o numero do cartao da pessoa que recebera a transferencia:");
			user.numeroTrans = sc.next();
			
			System.out.println("Informe a quantia a ser transferida:");
			user.quantia = sc.nextDouble();
			
			user.saldo = user.transferir();
			
			System.out.println("Voce transferiu R$"+user.quantia+" para "+user.nomeTrans);
			System.out.println("Seu novo saldo e: R$"+user.saldo);
			break;
			
		case 3:
			System.out.println("Escolha no que investir:\n1 - CDB\n2 - Tesouro Selic\n3 - Fundo multimercado\n4 - Cancelar");
			user.opcao = sc.nextInt();
			
			System.out.println("Qual o valor a ser investido?");
			user.quantia = sc.nextDouble();
			
			System.out.println("Aplicar R$"+user.quantia+" por quantos meses?");
			user.tempo = sc.nextInt();
			
			user.saldo += user.investir() - user.quantia;
			
			System.out.println("Voce aplicou R$"+user.quantia+" por "+user.tempo+" meses e ganhou R$"+user.investir);
			break;
		
		case 4:
			System.out.println("Qual o valor do emprestimo?");
			user.quantia = sc.nextDouble();
			
			System.out.println("Em quantos meses planeja realizar o pagamento do emprestimo?");
			user.tempo = sc.nextInt();
			
			user.saldo += user.quantia;
			user.quantiaTotal = user.emprestimo();
			
			user.notifEMP = 1;
			break;
			
			
		case 5:
			System.out.println("Nome: "+user.nome+"\nEndereco: "+user.endereco+"\nCPF: "+user.CPF+"\nProfissao: "+user.profissao+"\nRenda mensal: R$"+user.renda+"/mes\nNumero do cartao: "+user.numero+"\nAgencia: "+user.agencia+"\n");
			break;
			
		case 6:
			repeat = 1;
			break;
			
			}
		}while(repeat == 0);
		
		sc.close();
	}

}
