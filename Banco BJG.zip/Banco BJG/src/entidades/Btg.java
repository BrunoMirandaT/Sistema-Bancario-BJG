package entidades;

public class Btg {
	
	//Informa��es do cliente
		public String nome;
		public String endereco;
		public String CPF;
		public String profissao;
		public double renda;
		
		//Conta pessoal
		public long numero;
		public String agencia;
		public double saldo = 5000;
		
		//Informacoes para as funcoes do app
		public String nomeTrans;
		public String cpfTrans;
		public String agenciaTrans;
		public String numeroTrans;
		public double quantia;
		public int parcelas;
		public int opcao;
		public double selic = 1.15;
		public double ipca = 0.68;
		public double prefixado = 0.99;
		public int tempo;
		public double investir;
		public double quantiaJuros;
		public int notifEMP = 0;
		public double quantiaTotal;
		
		
		//Funcoes do app
		public double receber() {
			return saldo += renda; 
		}
		
		public double depositar() {
			return saldo += quantia;
		}
		
		public double transferir() {
			return saldo -= quantia;
		}
		
		
		public double investir() {
			switch(opcao) {
			case 1:
				return investir = quantia + (tempo * (quantia * 1.15));
				
			case 2:
				return investir = quantia + (tempo * (quantia * 0.68));
				
			case 3:
				return investir = quantia + (tempo * (quantia * 0.99));
				
			case 4:
				return opcao;
				
			default:
				System.out.println("Opcao invalida");
				return opcao;
			}
		}
		
		
		public double emprestimo() {
		 quantiaJuros = quantia + (tempo * (quantia * 0.06));
		 return quantiaTotal = quantiaJuros;
			
		}
		

}
